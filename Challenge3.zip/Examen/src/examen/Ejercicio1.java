/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen;

import javax.swing.JOptionPane;

/**
 *
 * @author Jeniffer
 */
public class Ejercicio1 {
    public static void main(String[] args) {
        
        String nombre;
        double sueldobase, sueldo2, sueldo3;
        int añosexperiencia;
        
        nombre = JOptionPane.showInputDialog("Ingresar nombre del trabajador: ");
        sueldobase = Double.parseDouble(JOptionPane.showInputDialog("Ingresar sueldo base del trabajador: "));
        añosexperiencia = Integer.parseInt(JOptionPane.showInputDialog("Ingresar años de experiencia del trabajador: "));
        
        sueldo2 = sueldobase + 350;
        sueldo3 = sueldobase + 700;
        
        if (añosexperiencia < 3){
            JOptionPane.showMessageDialog(null, "El sueldo final de: " + nombre + " es: "+ sueldobase); 
        }else if ( añosexperiencia <=5 ){
            JOptionPane.showMessageDialog(null, "El sueldo final de: " + nombre + " es: " + sueldo2);
        }else{
            JOptionPane.showMessageDialog(null, "El sueldo final de: " + nombre + " es: " + sueldo3);
        }
        
    }
    
}
        
        
    

