/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen;

import javax.swing.JOptionPane;

/**
 *
 * @author Jeniffer
 */
public class Ejercicio2 {
    public static void main(String[] args) {
         double numero1;
        double numero2;
        double suma, resta, multiplicacion, division;
        String resultados;
        
        numero1 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el primer número"));
        numero2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el segundo número"));
        
        suma = numero1 + numero2;
        resta = numero1 - numero2;
        multiplicacion = numero1 * numero2;
        division = numero1 / numero2; 
        
        resultados = "La suma es: " + suma + "\n" + 
                     "La resta es: " + resta + "\n" + 
                     "La multiplicación es: " + multiplicacion + "\n" + 
                     "La division es: " + division + "\n";
        
        JOptionPane.showMessageDialog(null,resultados);
    }
}
